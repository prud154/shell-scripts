#This Script Will Print 1 to 10.
for I in {1..10}; do
    echo $I
    sleep 1
done
