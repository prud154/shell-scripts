def average(eng,math,phy):
    sum = eng+math+phy
    all_avg = sum/3
    print(round(all_avg,2))
    return round(all_avg,2)