#This Script Will Check For Even Numbers
for I in {1..10}; do
    if [ $(expr $I % 2) -ne 0 ]; then
        echo "$I is ODD NUMBER"
    else
        echo "$I is EVEN NUMBER"
    fi
done
