#!/bin/bash
uptime
megastar
free
superstar
uname -a
rebelstar
df -h
youngtiger
ls -al
iconstar
