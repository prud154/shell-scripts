#!/bin/bash
WORD='MADAM'
WORD_LEN=${#WORD}
REVERSE=''
LENGTH=$(expr $WORD_LEN - 1)
for ((i = $LENGTH; i >= 0; i--)); do
    REVERSE=${REVERSE}${WORD[@]:$i:1}
done
if [[ "${WORD}" = "${REVERSE}" ]]; then
    echo "$WORD IS A PALINDROME"
else
    echo "$WORD IS NOT A PALINDROME"
fi
