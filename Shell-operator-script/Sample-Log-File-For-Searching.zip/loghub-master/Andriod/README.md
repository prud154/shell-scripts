## Android
Android (https://www.android.com) is a popular mobile operating system developed by Google and has been used by many smart devices. However, Andriod logs are rarely available in public for research purposes. We provide a log file, which was generated when we test an instrumented Android smartphone in our lab. Some other Android logs will be released soon.

Note that `Android_2k.log` is a sample log. The raw logs can be requested from Zenodo: https://doi.org/10.5281/zenodo.1144100
