## HealthApp

HealthApp is a mobile application for Andriod devices. We collected the application logs from an Android smartphone after 10+ days of use. 

Note that `HealthApp_2k.log` is a sample log. The raw logs can be requested from Zenodo: https://doi.org/10.5281/zenodo.1144100
