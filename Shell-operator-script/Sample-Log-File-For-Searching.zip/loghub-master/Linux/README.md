## Linux

Linux logs are usually located at `/var/log/`. The dataset was collected from `/var/log/messages` on a Linux server over a period of 260+ days, as part of the *[Public Security Log Sharing Site](http://log-sharing.dreamhosters.com/)* project. More similar logs are also available there.

Note that `Linux_2k.log` is a sample log. The raw logs can be requested from Zenodo: https://doi.org/10.5281/zenodo.1144100



